A server/ backend was added under the 'server/' folder. See server/README.md for instructions.
